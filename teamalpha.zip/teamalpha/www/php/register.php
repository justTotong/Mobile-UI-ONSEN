<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $name=$_POST['name'];
 $email=$_POST['email'];
 $password=$_POST['password'];
 $mobile=$_POST['mobile'];
 $mobile_2=$_POST['mobile_2'];
 $q=mysqli_query($con,"INSERT INTO `user` (`name`,`email`,`password`,`mobile`,`mobile_2`) VALUES ('$name','$email','$password','$mobile','$mobile_2')");
 if($q)
  echo "success";

 else
  echo "error";

 }

 ?>