<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","","phonegap") or die ("could not connect database");
?>